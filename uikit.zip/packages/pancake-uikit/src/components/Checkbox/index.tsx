export { default as Checkbox } from "./Checkbox";
export type { CheckboxProps, Scales as CheckboxScales } from "./types";
