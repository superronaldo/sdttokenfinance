export default {
  pancakeProfile: {
    56: "0xDf4dBf6536201370F95e06A0F8a7a70fE40E388a",
    97: "0x4B683C7E13B6d5D7fd1FeA9530F451954c1A7c8A",
  },
};
