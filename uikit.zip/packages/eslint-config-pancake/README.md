# eslint-config-pancake

Pancake Eslint config with:

- Airbnb config
- Typescript
- Prettier

## Usage

```
npx install-peerdeps --dev @pancakeswap/eslint-config-pancake
```

Add `"extends": "@pancakeswap/eslint-config-pancake"` to your eslint config file.
